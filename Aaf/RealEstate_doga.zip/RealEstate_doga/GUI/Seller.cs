﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealEstateGUI
{
    class Seller
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
    }
}
